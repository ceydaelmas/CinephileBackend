﻿using Application.Interfaces.Repositories;
using Domain.Entities;
using Infrastructure.Persistence.Contexts;
using Infrastructure.Persistence.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Persistence.Repositories
{
    public class FollowerRepositoryAsync : GenericRepositoryAsync<Follower>, IFollowerRepositoryAsync
    {
        private readonly DbSet<Follower> _follower;

        public FollowerRepositoryAsync(ApplicationDbContext dbContext) : base(dbContext)
        {
            _follower = dbContext.Set<Follower>();
        }
    }
}
