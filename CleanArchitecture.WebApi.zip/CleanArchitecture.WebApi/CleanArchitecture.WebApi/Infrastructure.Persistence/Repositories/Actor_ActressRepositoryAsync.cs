﻿using Application.Interfaces.Repositories;
using Domain.Entities;
using Infrastructure.Persistence.Contexts;
using Infrastructure.Persistence.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Persistence.Repositories
{
    public class Actor_ActressRepositoryAsync : GenericRepositoryAsync<Actor_Actress>, IActor_ActressRepositoryAsync
    {
        private readonly DbSet<Actor_Actress> _actor_actress;

        public Actor_ActressRepositoryAsync(ApplicationDbContext dbContext) : base(dbContext)
        {
            _actor_actress = dbContext.Set<Actor_Actress>();
        }
    }
}

