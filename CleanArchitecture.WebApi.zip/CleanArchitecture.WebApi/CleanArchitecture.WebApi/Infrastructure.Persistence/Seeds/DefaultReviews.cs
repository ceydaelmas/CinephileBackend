﻿using Application.Interfaces.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Persistence.Seeds
{
    public class DefaultReviews
    {
        public static async Task<bool> SeedAsync(IReviewRepositoryAsync reviewRepository)
        {

            var review1 = new Review
            {
                reviewContent="nice",

                filmId=1
            };



            var reviewList = await reviewRepository.GetAllAsync();
            var _review1 = reviewList.Where(p => p.reviewContent.StartsWith(review1.reviewContent)).Count();

            if (_review1 > 0) // ALREADY SEEDED
                return true;


            if (_review1 == 0)
                try
                {
                    await reviewRepository.AddAsync(review1);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw;
                }


            return false;

        }
    }
}
