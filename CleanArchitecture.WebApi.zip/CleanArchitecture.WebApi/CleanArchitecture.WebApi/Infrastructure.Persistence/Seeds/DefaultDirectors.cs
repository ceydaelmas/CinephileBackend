﻿using Application.Interfaces.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Persistence.Seeds
{
    public class DefaultDirectors
    {
        public static async Task<bool> SeedAsync(IDirectorRepositoryAsync directorRepository)
        {

            var director1 = new Director
            {
                directorName="Steven" ,
                directorSurname= "Spielberg",
                directorBrief="nice",
                directorImage="http/directorlink.com"//link
             };

            var directorList = await directorRepository.GetAllAsync();
            var _director1 = directorList.Where(p => p.directorName.StartsWith(director1.directorName)).Count();

            if (_director1 > 0) // ALREADY SEEDED
                return true;


            if (_director1 == 0)
                try
                {
                    await directorRepository.AddAsync(director1);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw;
                }


            return false;

        }
    }
}
