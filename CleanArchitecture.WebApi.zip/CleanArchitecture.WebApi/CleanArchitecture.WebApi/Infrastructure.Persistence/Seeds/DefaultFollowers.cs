﻿using Application.Interfaces.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Persistence.Seeds
{
    public class DefaultFollowers
    {
        public static async Task<bool> SeedAsync(IFollowerRepositoryAsync followerRepository)
        {

            var follower1 = new Follower
            {
                userId = 1,
                followerId = 2
            };



            var followerList = await followerRepository.GetAllAsync();
            var _follower1 = followerList.Where(p => p.userId.ToString().StartsWith(follower1.userId.ToString())).Count();

            if (_follower1 > 0) // ALREADY SEEDED
                return true;


            if (_follower1 == 0)
                try
                {
                    await followerRepository.AddAsync(follower1);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw;
                }


            return false;

        }
    }
}
