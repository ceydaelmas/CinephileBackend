﻿using Application.Interfaces.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Persistence.Seeds
{
    public class DefaultActors_Actresses
    {
        public static async Task<bool> SeedAsync(IActor_ActressRepositoryAsync actor_actressRepository)
        {

            var actor1 = new Actor_Actress
            {
                actorName = "Brad",
                actorSurname = "Pitt",
                actorBrief = "Nice",
                actorImage = "http/foto.com"
            };

            var actorList = await actor_actressRepository.GetAllAsync();
            var _actor1 = actorList.Where(p => p.actorName.StartsWith(actor1.actorName)).Count();

            if (_actor1 > 0) // ALREADY SEEDED
                return true;


            if (_actor1 == 0)
                try
                {
                    await actor_actressRepository.AddAsync(actor1);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw;
                }


            return false;

        }
    }
}
