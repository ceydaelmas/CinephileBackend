using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http.Extensions;
using Serilog;
using Infrastructure.Identity;
using Microsoft.AspNetCore.Identity;
using Infrastructure.Identity.Models;
using Microsoft.Extensions.DependencyInjection;
using Application.Interfaces.Repositories;

namespace WebApi
{
    public class Program
    {
        public async static Task Main(string[] args)
        {
            //Read Configuration from appSettings
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            //Initialize Logger
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(config)
                .CreateLogger();
            var host = CreateHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var loggerFactory = services.GetRequiredService<ILoggerFactory>();
                try
                {
                    var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
                    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

                    await Infrastructure.Identity.Seeds.DefaultRoles.SeedAsync(userManager, roleManager);
                    await Infrastructure.Identity.Seeds.DefaultSuperAdmin.SeedAsync(userManager, roleManager);
                    await Infrastructure.Identity.Seeds.DefaultBasicUser.SeedAsync(userManager, roleManager);



                    var filmRepository = services.GetRequiredService<IFilmmRepositoryAsync>();
                    var actor_actressRepository = services.GetRequiredService<IActor_ActressRepositoryAsync>();
                    var reviewRepository = services.GetRequiredService<IReviewRepositoryAsync>();
                    var directorRepository = services.GetRequiredService<IDirectorRepositoryAsync>();
                    var followerRepository = services.GetRequiredService<IFollowerRepositoryAsync>();
                    var searchRepository = services.GetRequiredService<ISearchRepositoryAsync>();
                    var watchedListRepository = services.GetRequiredService<IWatchedListRepositoryAsync>();
                    var watchListproductRepository = services.GetRequiredService<IWatchListRepositoryAsync>();
                    var diaryRepository = services.GetRequiredService<IDiaryRepositoryAsync>();

                   
                   // var eventRepository = services.GetRequiredService<IEventRepositoryAsync>();
                    //var logger = services.GetRequiredService<Microsoft.Extensions.Logging.ILogger>();
                  
                    await Infrastructure.Persistence.Seeds.DefaultFilms.SeedAsync(filmRepository);
                    await Infrastructure.Persistence.Seeds.DefaultReviews.SeedAsync(reviewRepository);
                    await Infrastructure.Persistence.Seeds.DefaultActors_Actresses.SeedAsync(actor_actressRepository);
                    await Infrastructure.Persistence.Seeds.DefaultDirectors.SeedAsync(directorRepository);
                    await Infrastructure.Persistence.Seeds.DefaultFollowers.SeedAsync(followerRepository);
                    await Infrastructure.Persistence.Seeds.DefaultSearches.SeedAsync(searchRepository);
                    await Infrastructure.Persistence.Seeds.DefaultWatchedLists.SeedAsync(watchedListRepository);
                    await Infrastructure.Persistence.Seeds.DefaultWatchLists.SeedAsync(watchListproductRepository);
                    await Infrastructure.Persistence.Seeds.DefaultDiaries.SeedAsync(diaryRepository);

                    
                    //await Infrastructure.Persistence.Seeds.DefaultEvents.SeedAsync(eventRepository, personnelRepository,addressRepository);

                    Log.Information("Finished Seeding Default Data");
                    Log.Information("Application Starting");
                    host.Run();
                }
                catch (Exception ex)
                {
                    Log.Warning(ex, "An error occurred seeding the DB");
                }
                finally
                {
                    Log.CloseAndFlush();
                }
            }

        }
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
            .UseSerilog() //Uses Serilog instead of default .NET Logger
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
