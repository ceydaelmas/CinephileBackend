﻿using Application.Features.Reviews.Commands.CreateReview;
using Application.Features.Reviews.Commands.DeleteReviewById;
using Application.Features.Reviews.Commands.UpdateReview;
using Application.Features.Reviews.Queries.GetAllReviews;
using Application.Features.Reviews.Queries.GetReviewById;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace WebApi.Controllers.v1
{
    [ApiVersion("1.0")]
    public class ReviewController : BaseApiController
    {
        // GET: api/<controller>
        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] GetAllReviewsParameter filter)
        {

            return Ok(await Mediator.Send(new GetAllReviewsQuery() { PageSize = filter.PageSize, PageNumber = filter.PageNumber }));
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok(await Mediator.Send(new GetReviewByIdQuery { Id = id }));
        }

        // POST api/<controller>
        [HttpPost]
        //        [Authorize]
        public async Task<IActionResult> Post(CreateReviewCommand command)
        {
            return Ok(await Mediator.Send(command));
        }
        // PUT api/<controller>/5
        [HttpPut("{id}")]
        //[Authorize]
        public async Task<IActionResult> Put(int id, UpdateReviewCommand command)
        {
            if (id != command.Id)
            {
                return BadRequest();
            }
            return Ok(await Mediator.Send(command));
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        //       [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await Mediator.Send(new DeleteReviewByIdCommand { Id = id }));
        }
    }
}
