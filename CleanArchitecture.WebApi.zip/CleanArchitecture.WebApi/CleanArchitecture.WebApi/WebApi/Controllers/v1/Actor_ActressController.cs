﻿using Application.Features.Actors_Actresses.Commands.CreateActor_Actress;
using Application.Features.Actors_Actresses.Commands.DeleteActor_ActressById;
using Application.Features.Actors_Actresses.Commands.UpdateActor_Actress;
using Application.Features.Actors_Actresses.Queries.GetActor_ActressById;
using Application.Features.Actors_Actresses.Queries.GetAllActors_Actresses;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace WebApi.Controllers.v1 {
    [ApiVersion("1.0")]
    public class Actor_ActressController : BaseApiController
    {
        // GET: api/<controller>
        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] GetAllActors_ActressesParameter filter)
        {

            return Ok(await Mediator.Send(new GetAllActors_ActressesQuery() { PageSize = filter.PageSize, PageNumber = filter.PageNumber }));
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok(await Mediator.Send(new GetActor_ActressByIdQuery { Id = id }));
        }

        // POST api/<controller>
        [HttpPost]
        //        [Authorize]
        public async Task<IActionResult> Post(CreateActor_ActressCommand command)
        {
            return Ok(await Mediator.Send(command));
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        //[Authorize]
        public async Task<IActionResult> Put(int id, UpdateActor_ActressCommand command)
        {
            if (id != command.Id)
            {
                return BadRequest();
            }
            return Ok(await Mediator.Send(command));
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        //       [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await Mediator.Send(new DeleteActor_ActressByIdCommand { Id = id }));
        }

    }
}
