
using AutoMapper;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

using Application.Features.Films.Queries.GetAllFilms;
using Application.Features.Films.Commands.CreateFilm;
using Application.Features.Diaries.Commands.CreateDiaries;
using Application.Features.Diaries.Queries.GetAllDiaries;
using Application.Features.Searches.Queries.GetAllSearches;
using Application.Features.Searches.Commands.CreateSearch;
using Application.Features.WatchedLists.Queries.GetAllWatchedLists;
using Application.Features.WatchedLists.Commands.CreateWatchedList;
using Application.Features.WatchLists.Queries.GetAllWatchLists;
using Application.Features.WatchLists.Commands.CreateWatchList;
using Application.Features.Actors_Actresses.Queries.GetAllActors_Actresses;
using Application.Features.Actors_Actresses.Commands.CreateActor_Actress;
using Application.Features.Followers.Queries.GetAllFollowers;
using Application.Features.Followers.Commands.CreateFollower;
using Application.Features.Directors.Queries.GetAllDirectors;
using Application.Features.Directors.Commands.CreateDirector;
using Application.Features.Reviews.Queries.GetAllReviews;
using Application.Features.Reviews.Commands.CreateReview;
using Application.Features.Actors_Actresses.Commands.UpdateActor_Actress;
using Application.Features.Directors.Commands.UpdateDirector;
using Application.Features.Diaries.Commands.UpdateDiary;
using Application.Features.Films.Commands.UpdateFilm;
using Application.Features.Reviews.Commands.UpdateReview;

namespace Application.Mappings
{
    public class GeneralProfile : Profile
    {
        public GeneralProfile()
        {

            CreateMap<Actor_Actress, GetAllActors_ActressesViewModel>().ReverseMap();
            CreateMap<CreateActor_ActressCommand, Actor_Actress>();
            CreateMap<GetAllActors_ActressesQuery, GetAllActors_ActressesParameter>();
            CreateMap<UpdateActor_ActressCommand, Actor_Actress>();

            CreateMap<Follower, GetAllFollowersViewModel>().ReverseMap();
            CreateMap<CreateFollowerCommand, Follower>();
            CreateMap<GetAllFollowersQuery, GetAllFollowersParameter>();

            CreateMap<Director, GetAllDirectorsViewModel>().ReverseMap();
            CreateMap<CreateDirectorCommand, Director>();
            CreateMap<GetAllDirectorsQuery, GetAllDirectorsParameter>();
            CreateMap<UpdateDirectorCommand,Director>();

            CreateMap<Review, GetAllReviewsViewModel>().ReverseMap();
            CreateMap<CreateReviewCommand, Review>();
            CreateMap<GetAllReviewsQuery, GetAllReviewsParameter>();
            CreateMap<UpdateReviewCommand, Review>();


            CreateMap<Diary, GetAllDiariesViewModel>();
            CreateMap<CreateDiaryCommand, Diary>();
            CreateMap<GetAllDiariesQuery, GetAllDiariesParameter>();
            CreateMap<UpdateDiaryCommand, Diary>();

            CreateMap<Film, GetAllFilmsViewModel>();
            CreateMap<CreateFilmCommand, Film>();
            CreateMap<GetAllFilmsQuery, GetAllFilmsParameter>();
            CreateMap<UpdateFilmCommand, Film>();

            CreateMap<Search, GetAllSearchesViewModel>();
            CreateMap<CreateSearchCommand, Search>();
            CreateMap<GetAllSearchesQuery, GetAllSearchesParameter>();

            CreateMap<WatchedList, GetAllWatchedListsViewModel>();
            CreateMap<CreateWatchedListCommand, WatchedList>();
            CreateMap<GetAllWatchedListsQuery, GetAllWatchedListsParameter>();

            CreateMap<WatchList, GetAllWatchListsViewModel>();
            CreateMap<CreateWatchListCommand, WatchList>();
            CreateMap<GetAllWatchListsQuery, GetAllWatchListsParameter>();



        }
    }
}
