﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Enums
{
    public enum Roles//role göre hangi apilere erişebileceğini söyleyebiliyorsun. 
    {
        SuperAdmin,
        Admin,
        Moderator,
        Basic,
        Manager,
        Employee
    }
}
