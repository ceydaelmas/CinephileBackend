﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.WatchLists.Queries.GetAllWatchLists
{
    public class GetAllWatchListsViewModel
    {
        public int? filmId { get; set; }
    }
}
