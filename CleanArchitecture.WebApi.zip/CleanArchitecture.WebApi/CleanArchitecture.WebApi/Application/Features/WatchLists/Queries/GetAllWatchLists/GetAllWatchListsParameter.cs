﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.WatchLists.Queries.GetAllWatchLists
{
    public class GetAllWatchListsParameter : RequestParameter
    {
    }
}
