﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.WatchLists.Commands.DeleteWatchListById
{
    public class DeleteWatchListByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteWatchListByIdCommandHandler : IRequestHandler<DeleteWatchListByIdCommand, Response<int>>
        {
            private readonly IWatchListRepositoryAsync _watchListRepository;
            public DeleteWatchListByIdCommandHandler(IWatchListRepositoryAsync watchListRepository)
            {
                _watchListRepository = watchListRepository;
            }
            public async Task<Response<int>> Handle(DeleteWatchListByIdCommand command, CancellationToken cancellationToken)
            {
                var watchList = await _watchListRepository.GetByIdAsync(command.Id);
                if (watchList == null) throw new ApiException($"Watch List Not Found.");
                await _watchListRepository.DeleteAsync(watchList);
                return new Response<int>(watchList.Id);
            }
        }
    }
}
