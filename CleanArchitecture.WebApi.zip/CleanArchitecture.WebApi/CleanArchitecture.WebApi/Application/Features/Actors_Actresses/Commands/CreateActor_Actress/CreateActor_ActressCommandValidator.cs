﻿using Application.Interfaces.Repositories;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Actors_Actresses.Commands.CreateActor_Actress
{
    public class CreateActor_ActressCommandValidator : AbstractValidator<CreateActor_ActressCommand>
    {
        private readonly IActor_ActressRepositoryAsync actor_actressRepository;

        public CreateActor_ActressCommandValidator(IActor_ActressRepositoryAsync actor_actressRepository)
        {
            this.actor_actressRepository = actor_actressRepository;

            RuleFor(p => p.actorName)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull()
                .MaximumLength(50).WithMessage("{PropertyName} must not exceed 50 characters.");

            RuleFor(p => p.actorSurname)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull()
                .MaximumLength(50).WithMessage("{PropertyName} must not exceed 50 characters.");

            RuleFor(p => p.actorBrief)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull()
                .MaximumLength(50).WithMessage("{PropertyName} must not exceed 50 characters.");
           
            RuleFor(p => p.actorImage)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull()
                .MaximumLength(50).WithMessage("{PropertyName} must not exceed 50 characters.");
        }
    }
}
