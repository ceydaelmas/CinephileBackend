﻿
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace Application.Features.Actors_Actresses.Commands.CreateActor_Actress
{
    public partial class CreateActor_ActressCommand : IRequest<Response<int>>
    {
        public string actorName { get; set; }
        public string actorSurname { get; set; }
        public string actorBrief { get; set; }
        public string actorImage { get; set; }//link
    }
    public class CreateActor_ActressCommandHandler : IRequestHandler<CreateActor_ActressCommand, Response<int>>
    {
        private readonly IActor_ActressRepositoryAsync _actor_actressRepository;
        private readonly IMapper _mapper;
        public CreateActor_ActressCommandHandler(IActor_ActressRepositoryAsync actor_actressRepository, IMapper mapper)
        {
            _actor_actressRepository = actor_actressRepository;
            _mapper = mapper;
        }

        public async Task<Response<int>> Handle(CreateActor_ActressCommand request, CancellationToken cancellationToken)
        {
            var actor_actress = _mapper.Map<Actor_Actress>(request);
            await _actor_actressRepository.AddAsync(actor_actress);
            return new Response<int>(actor_actress.Id);
        }
    }
}
