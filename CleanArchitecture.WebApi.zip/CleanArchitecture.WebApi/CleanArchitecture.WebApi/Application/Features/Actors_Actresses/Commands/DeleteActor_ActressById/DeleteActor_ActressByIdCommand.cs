﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Actors_Actresses.Commands.DeleteActor_ActressById
{
    public class DeleteActor_ActressByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteActor_ActressByIdCommandHandler : IRequestHandler<DeleteActor_ActressByIdCommand, Response<int>>
        {
            private readonly IActor_ActressRepositoryAsync _actor_actressRepository;
            public DeleteActor_ActressByIdCommandHandler(IActor_ActressRepositoryAsync actor_actressRepository)
            {
                _actor_actressRepository = actor_actressRepository;
            }
            public async Task<Response<int>> Handle(DeleteActor_ActressByIdCommand command, CancellationToken cancellationToken)
            {
                var actor_actress = await _actor_actressRepository.GetByIdAsync(command.Id);
                if (actor_actress == null) throw new ApiException($"Actor Not Found.");
                await _actor_actressRepository.DeleteAsync(actor_actress);
                return new Response<int>(actor_actress.Id);
            }
        }
    }
}
