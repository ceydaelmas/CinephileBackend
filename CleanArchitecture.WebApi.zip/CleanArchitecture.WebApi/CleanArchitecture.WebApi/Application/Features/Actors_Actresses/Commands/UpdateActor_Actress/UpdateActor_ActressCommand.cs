﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Actors_Actresses.Commands.UpdateActor_Actress
{
    public class UpdateActor_ActressCommand  : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public string actorName { get; set; }
        public string actorSurname { get; set; }
        public string actorBrief { get; set; }
        public string actorImage { get; set; }//link
        public class UpdateActor_ActressCommandHandler : IRequestHandler<UpdateActor_ActressCommand, Response<int>>
        {
            private readonly IActor_ActressRepositoryAsync _actor_actressRepository;
            private readonly IMapper _mapper;
            public UpdateActor_ActressCommandHandler(IActor_ActressRepositoryAsync actor_actressRepository, IMapper mapper)
            {
                _actor_actressRepository = actor_actressRepository;
                _mapper = mapper;
            }
            public async Task<Response<int>> Handle(UpdateActor_ActressCommand request, CancellationToken cancellationToken)
            {
                var _actor_actress = await _actor_actressRepository.GetByIdAsync(request.Id);

                if (_actor_actress == null)
                {
                    throw new ApiException($"Actor Not Found.");
                }
                else
                {
                    _actor_actress = _mapper.Map<Actor_Actress>(request);
                    await _actor_actressRepository.UpdateAsync(_actor_actress);
                    return new Response<int>(_actor_actress.Id);
                }
            }
        }
    }
}
