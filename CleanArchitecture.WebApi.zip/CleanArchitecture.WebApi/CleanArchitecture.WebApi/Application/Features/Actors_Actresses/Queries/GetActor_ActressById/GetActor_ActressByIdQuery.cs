﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Actors_Actresses.Queries.GetActor_ActressById
{
    public class GetActor_ActressByIdQuery : IRequest<Response<Actor_Actress>>
    {
        public int Id { get; set; }
        public class GetActor_ActressByIdQueryHandler : IRequestHandler<GetActor_ActressByIdQuery, Response<Actor_Actress>>
        {
            private readonly IActor_ActressRepositoryAsync _actor_actressRepository;
            public GetActor_ActressByIdQueryHandler(IActor_ActressRepositoryAsync actor_actressRepository)
            {
                _actor_actressRepository = actor_actressRepository;
            }
            public async Task<Response<Actor_Actress>> Handle(GetActor_ActressByIdQuery query, CancellationToken cancellationToken)
            {
                var actor_actress = await _actor_actressRepository.GetByIdAsync(query.Id);
                if (actor_actress == null) throw new ApiException($"Actor Not Found.");
                return new Response<Actor_Actress>(actor_actress);
            }
        }
    }
}
