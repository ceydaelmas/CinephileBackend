﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Actors_Actresses.Queries.GetAllActors_Actresses
{
    public class GetAllActors_ActressesParameter : RequestParameter
    {
    }
}
