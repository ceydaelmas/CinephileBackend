﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Actors_Actresses.Queries.GetAllActors_Actresses
{
    public class GetAllActors_ActressesViewModel
    {
        public string actorName { get; set; }
        public string actorSurname { get; set; }
        public string actorBrief { get; set; }
        public string actorImage { get; set; }//link
    }
}
