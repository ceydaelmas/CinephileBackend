﻿using Application.Features.Films.Queries.GetAllFilms;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Actors_Actresses.Queries.GetAllActors_Actresses
{
    public class GetAllActors_ActressesQuery : IRequest<PagedResponse<IEnumerable<GetAllActors_ActressesViewModel>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
    public class GetAllActors_ActressesQueryHandler : IRequestHandler<GetAllActors_ActressesQuery, PagedResponse<IEnumerable<GetAllActors_ActressesViewModel>>>
    {
        private readonly IActor_ActressRepositoryAsync _actor_actressRepository;
        private readonly IMapper _mapper;
        public GetAllActors_ActressesQueryHandler(IActor_ActressRepositoryAsync actor_actressRepository, IMapper mapper)
        {
            _actor_actressRepository = actor_actressRepository;
            _mapper = mapper;
        }

        public async Task<PagedResponse<IEnumerable<GetAllActors_ActressesViewModel>>> Handle(GetAllActors_ActressesQuery request, CancellationToken cancellationToken)
        {
            var validFilter = _mapper.Map<GetAllActors_ActressesParameter>(request);

            var _actor_actress = await _actor_actressRepository.GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);

            //  GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);
            var actor_actressViewModel = _mapper.Map<IEnumerable<GetAllActors_ActressesViewModel>>(_actor_actress);
            return new PagedResponse<IEnumerable<GetAllActors_ActressesViewModel>>(actor_actressViewModel, validFilter.PageNumber, validFilter.PageSize);
        }
    }
}
