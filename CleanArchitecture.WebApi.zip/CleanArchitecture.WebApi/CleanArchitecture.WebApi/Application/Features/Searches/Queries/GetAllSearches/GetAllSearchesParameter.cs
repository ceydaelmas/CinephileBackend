﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Searches.Queries.GetAllSearches
{
    public class GetAllSearchesParameter : RequestParameter
    {
    }
}
