﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Searches.Queries.GetAllSearches
{
    public class GetAllSearchesViewModel
    {
        public string searchContent { get; set; }
    }
}
