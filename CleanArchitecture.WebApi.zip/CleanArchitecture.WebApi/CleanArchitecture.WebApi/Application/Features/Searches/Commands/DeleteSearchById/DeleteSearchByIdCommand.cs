﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Searchs.Commands.DeleteSearchById
{
    public class DeleteSearchByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteSearchByIdCommandHandler : IRequestHandler<DeleteSearchByIdCommand, Response<int>>
        {
            private readonly ISearchRepositoryAsync _searchRepository;
            public DeleteSearchByIdCommandHandler(ISearchRepositoryAsync searchRepository)
            {
                _searchRepository = searchRepository;
            }
            public async Task<Response<int>> Handle(DeleteSearchByIdCommand command, CancellationToken cancellationToken)
            {
                var search = await _searchRepository.GetByIdAsync(command.Id);
                if (search == null) throw new ApiException($"Search Not Found.");
                await _searchRepository.DeleteAsync(search);
                return new Response<int>(search.Id);
            }
        }
    }
}
