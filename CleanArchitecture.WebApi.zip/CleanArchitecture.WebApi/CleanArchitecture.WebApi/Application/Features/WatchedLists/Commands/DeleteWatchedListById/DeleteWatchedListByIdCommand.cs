﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.WatchedLists.Commands.DeleteWatchedListById
{
    public class DeleteWatchedListByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteWatchedListByIdCommandHandler : IRequestHandler<DeleteWatchedListByIdCommand, Response<int>>
        {
            private readonly IWatchedListRepositoryAsync _watchedListRepository;
            public DeleteWatchedListByIdCommandHandler(IWatchedListRepositoryAsync watchedListRepository)
            {
                _watchedListRepository = watchedListRepository;
            }
            public async Task<Response<int>> Handle(DeleteWatchedListByIdCommand command, CancellationToken cancellationToken)
            {
                var watchedList = await _watchedListRepository.GetByIdAsync(command.Id);
                if (watchedList == null) throw new ApiException($"Watched List Not Found.");
                await _watchedListRepository.DeleteAsync(watchedList);
                return new Response<int>(watchedList.Id);
            }
        }
    }
}
