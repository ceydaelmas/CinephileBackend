﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.WatchedLists.Queries.GetAllWatchedLists
{
    public class GetAllWatchedListsViewModel
    {
        public int? filmId { get; set; }
    }
}
