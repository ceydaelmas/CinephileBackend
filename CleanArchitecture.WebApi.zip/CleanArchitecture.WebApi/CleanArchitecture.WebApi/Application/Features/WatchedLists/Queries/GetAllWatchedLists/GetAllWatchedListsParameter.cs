﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.WatchedLists.Queries.GetAllWatchedLists
{
    public class GetAllWatchedListsParameter : RequestParameter
    {
    }
}

