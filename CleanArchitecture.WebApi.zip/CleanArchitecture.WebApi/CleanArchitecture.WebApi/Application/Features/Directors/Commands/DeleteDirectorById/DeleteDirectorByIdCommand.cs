﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Directors.Commands.DeleteDirectorById
{
    public class DeleteDirectorByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteDirectorByIdCommandHandler : IRequestHandler<DeleteDirectorByIdCommand, Response<int>>
        {
            private readonly IDirectorRepositoryAsync _directorRepository;
            public DeleteDirectorByIdCommandHandler(IDirectorRepositoryAsync directorRepository)
            {
                _directorRepository = directorRepository;
            }
            public async Task<Response<int>> Handle(DeleteDirectorByIdCommand command, CancellationToken cancellationToken)
            {
                var director = await _directorRepository.GetByIdAsync(command.Id);
                if (director == null) throw new ApiException($"Director Not Found.");
                await _directorRepository.DeleteAsync(director);
                return new Response<int>(director.Id);
            }
        }
    }
}
