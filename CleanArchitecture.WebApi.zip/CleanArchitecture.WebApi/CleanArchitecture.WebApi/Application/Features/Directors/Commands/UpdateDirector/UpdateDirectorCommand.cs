﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Directors.Commands.UpdateDirector
{
    public class UpdateDirectorCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public string directorName { get; set; }
        public string directorSurname { get; set; }
        public string directorBrief { get; set; }
        public string directorImage { get; set; }//link
        public class UpdateDirectorCommandHandler : IRequestHandler<UpdateDirectorCommand, Response<int>>
        {
            private readonly IDirectorRepositoryAsync _directorRepository;
            private readonly IMapper _mapper;
            public UpdateDirectorCommandHandler(IDirectorRepositoryAsync directorRepository, IMapper mapper)
            {
                _directorRepository = directorRepository;
                _mapper = mapper;
            }
            public async Task<Response<int>> Handle(UpdateDirectorCommand request, CancellationToken cancellationToken)
            {
                var _director = await _directorRepository.GetByIdAsync(request.Id);

                if (_director == null)
                {
                    throw new ApiException($"Director Not Found.");
                }
                else
                {
                    _director = _mapper.Map<Director>(request);
                    await _directorRepository.UpdateAsync(_director);
                    return new Response<int>(_director.Id);
                }
            }
        }
    }
}
