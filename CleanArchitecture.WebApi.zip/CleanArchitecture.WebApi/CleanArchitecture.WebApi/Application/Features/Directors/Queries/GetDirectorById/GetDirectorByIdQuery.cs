﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Directors.Queries.GetDirectorById
{
    public class GetDirectorByIdQuery : IRequest<Response<Director>>
    {
        public int Id { get; set; }
        public class GetDirectorByIdQueryHandler : IRequestHandler<GetDirectorByIdQuery, Response<Director>>
        {
            private readonly IDirectorRepositoryAsync _directorRepository;
            public GetDirectorByIdQueryHandler(IDirectorRepositoryAsync directorRepository)
            {
                _directorRepository = directorRepository;
            }
            public async Task<Response<Director>> Handle(GetDirectorByIdQuery query, CancellationToken cancellationToken)
            {
                var director = await _directorRepository.GetByIdAsync(query.Id);
                if (director == null) throw new ApiException($"Director Not Found.");
                return new Response<Director>(director);
            }
        }
    }
}
