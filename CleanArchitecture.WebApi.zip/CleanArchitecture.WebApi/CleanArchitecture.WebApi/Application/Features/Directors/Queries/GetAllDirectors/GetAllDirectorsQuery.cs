﻿using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Directors.Queries.GetAllDirectors
{
    public class GetAllDirectorsQuery : IRequest<PagedResponse<IEnumerable<GetAllDirectorsViewModel>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
    public class GetAllDirectorsQueryHandler : IRequestHandler<GetAllDirectorsQuery, PagedResponse<IEnumerable<GetAllDirectorsViewModel>>>
    {
        private readonly IDirectorRepositoryAsync _directorRepository;
        private readonly IMapper _mapper;
        public GetAllDirectorsQueryHandler(IDirectorRepositoryAsync directorRepository, IMapper mapper)
        {
            _directorRepository = directorRepository;
            _mapper = mapper;
        }

        public async Task<PagedResponse<IEnumerable<GetAllDirectorsViewModel>>> Handle(GetAllDirectorsQuery request, CancellationToken cancellationToken)
        {
            var validFilter = _mapper.Map<GetAllDirectorsParameter>(request);

            var _director = await _directorRepository.GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);

            //  GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);
            var directorViewModel = _mapper.Map<IEnumerable<GetAllDirectorsViewModel>>(_director);
            return new PagedResponse<IEnumerable<GetAllDirectorsViewModel>>(directorViewModel, validFilter.PageNumber, validFilter.PageSize);
        }
    }
}
