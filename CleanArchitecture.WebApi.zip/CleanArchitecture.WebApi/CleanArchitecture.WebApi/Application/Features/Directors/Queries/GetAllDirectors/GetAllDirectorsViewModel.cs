﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Directors.Queries.GetAllDirectors
{
    public class GetAllDirectorsViewModel
    {
        public string directorName { get; set; }
        public string directorSurname { get; set; }
        public string directorBrief { get; set; }
        public string directorImage { get; set; }//link
    }
}
