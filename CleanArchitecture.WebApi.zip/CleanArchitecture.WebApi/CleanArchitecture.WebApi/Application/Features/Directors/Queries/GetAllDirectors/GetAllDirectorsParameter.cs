﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Directors.Queries.GetAllDirectors
{
    public class GetAllDirectorsParameter : RequestParameter
    {
    }
}
