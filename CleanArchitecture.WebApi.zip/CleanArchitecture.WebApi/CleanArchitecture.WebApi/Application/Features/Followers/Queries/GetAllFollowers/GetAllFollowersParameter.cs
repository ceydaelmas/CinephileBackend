﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Followers.Queries.GetAllFollowers
{
    public class GetAllFollowersParameter : RequestParameter
    {
    }
}
