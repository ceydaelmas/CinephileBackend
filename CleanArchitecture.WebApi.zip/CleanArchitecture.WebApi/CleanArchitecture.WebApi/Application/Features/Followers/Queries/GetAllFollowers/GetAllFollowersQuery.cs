﻿using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Followers.Queries.GetAllFollowers
{
    public class GetAllFollowersQuery : IRequest<PagedResponse<IEnumerable<GetAllFollowersViewModel>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
    public class GetAllFollowersQueryHandler : IRequestHandler<GetAllFollowersQuery, PagedResponse<IEnumerable<GetAllFollowersViewModel>>>
    {
        private readonly IFollowerRepositoryAsync _followerRepository;
        private readonly IMapper _mapper;
        public GetAllFollowersQueryHandler(IFollowerRepositoryAsync followerRepository, IMapper mapper)
        {
            _followerRepository = followerRepository;
            _mapper = mapper;
        }

        public async Task<PagedResponse<IEnumerable<GetAllFollowersViewModel>>> Handle(GetAllFollowersQuery request, CancellationToken cancellationToken)
        {
            var validFilter = _mapper.Map<GetAllFollowersParameter>(request);

            var _follower = await _followerRepository.GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);

            //  GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);
            var followerViewModel = _mapper.Map<IEnumerable<GetAllFollowersViewModel>>(_follower);
            return new PagedResponse<IEnumerable<GetAllFollowersViewModel>>(followerViewModel, validFilter.PageNumber, validFilter.PageSize);
        }
    }
}
