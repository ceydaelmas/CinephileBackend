﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Followers.Queries.GetAllFollowers
{
    public class GetAllFollowersViewModel
    {
        public int userId { get; set; }  //followed person
        public int followerId { get; set; } //follower
    }
}
