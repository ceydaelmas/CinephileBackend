﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Followers.Queries.GetFollowerById
{
    public class GetFollowerByIdQuery : IRequest<Response<Follower>>
    {
        public int Id { get; set; }
        public class GetFollowerByIdQueryHandler : IRequestHandler<GetFollowerByIdQuery, Response<Follower>>
        {
            private readonly IFollowerRepositoryAsync _followerRepository;
            public GetFollowerByIdQueryHandler(IFollowerRepositoryAsync followerRepository)
            {
                _followerRepository = followerRepository;
            }
            public async Task<Response<Follower>> Handle(GetFollowerByIdQuery query, CancellationToken cancellationToken)
            {
                var follower = await _followerRepository.GetByIdAsync(query.Id);
                if (follower == null) throw new ApiException($"Follower Not Found.");
                return new Response<Follower>(follower);
            }
        }
    }
}
