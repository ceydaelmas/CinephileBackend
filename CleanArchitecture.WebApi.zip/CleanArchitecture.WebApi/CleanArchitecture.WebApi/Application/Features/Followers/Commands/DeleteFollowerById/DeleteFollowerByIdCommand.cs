﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Followers.Commands.DeleteFollowerById
{
    public class DeleteFollowerByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteFollowerByIdCommandHandler : IRequestHandler<DeleteFollowerByIdCommand, Response<int>>
        {
            private readonly IFollowerRepositoryAsync _followerRepository;
            public DeleteFollowerByIdCommandHandler(IFollowerRepositoryAsync followerRepository)
            {
                _followerRepository = followerRepository;
            }
            public async Task<Response<int>> Handle(DeleteFollowerByIdCommand command, CancellationToken cancellationToken)
            {
                var follower = await _followerRepository.GetByIdAsync(command.Id);
                if (follower == null) throw new ApiException($"Follower Not Found.");
                await _followerRepository.DeleteAsync(follower);
                return new Response<int>(follower.Id);
            }
        }
    }
}
