﻿using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Followers.Commands.CreateFollower
{
    public partial class CreateFollowerCommand : IRequest<Response<int>>
    {
        public int userId { get; set; }  //followed person
        public int followerId { get; set; } //follower
    }
    public class CreateFollowerCommandHandler : IRequestHandler<CreateFollowerCommand, Response<int>>
    {
        private readonly IFollowerRepositoryAsync _followerRepository;
        private readonly IMapper _mapper;
        public CreateFollowerCommandHandler(IFollowerRepositoryAsync followerRepository, IMapper mapper)
        {
            _followerRepository = followerRepository;
            _mapper = mapper;
        }

        public async Task<Response<int>> Handle(CreateFollowerCommand request, CancellationToken cancellationToken)
        {
            var follower = _mapper.Map<Follower>(request);
            await _followerRepository.AddAsync(follower);
            return new Response<int>(follower.Id);
        }
    }
}
