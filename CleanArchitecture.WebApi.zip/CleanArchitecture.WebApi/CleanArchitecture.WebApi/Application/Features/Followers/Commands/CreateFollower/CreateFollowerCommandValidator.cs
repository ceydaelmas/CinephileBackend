﻿using Application.Interfaces.Repositories;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Followers.Commands.CreateFollower
{
    public class CreateFollowerCommandValidator : AbstractValidator<CreateFollowerCommand>
    {
        private readonly IFollowerRepositoryAsync followerRepository;

        public CreateFollowerCommandValidator(IFollowerRepositoryAsync followerRepository)
        {
            this.followerRepository = followerRepository;

            RuleFor(p => p.userId)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull();
               

            RuleFor(p => p.followerId)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull();

        }
    }
}
