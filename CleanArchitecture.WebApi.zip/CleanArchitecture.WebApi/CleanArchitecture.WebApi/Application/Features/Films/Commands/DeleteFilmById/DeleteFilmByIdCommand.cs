﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Films.Commands.DeleteFilmById
{
    public class DeleteFilmByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteFilmByIdCommandHandler : IRequestHandler<DeleteFilmByIdCommand, Response<int>>
        {
            private readonly IFilmmRepositoryAsync _filmRepository;
            public DeleteFilmByIdCommandHandler(IFilmmRepositoryAsync filmRepository)
            {
                _filmRepository = filmRepository;
            }
            public async Task<Response<int>> Handle(DeleteFilmByIdCommand command, CancellationToken cancellationToken)
            {
                var film = await _filmRepository.GetByIdAsync(command.Id);
                if (film == null) throw new ApiException($"Film Not Found.");
                await _filmRepository.DeleteAsync(film);
                return new Response<int>(film.Id);
            }
        }
    }
}
