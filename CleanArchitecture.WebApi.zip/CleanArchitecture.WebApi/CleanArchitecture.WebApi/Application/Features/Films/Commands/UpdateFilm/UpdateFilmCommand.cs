﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Films.Commands.UpdateFilm
{
    public class UpdateFilmCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public string filmName { get; set; }
        public int releaseYear { get; set; }
        public string genre { get; set; }
        public string filmBrief { get; set; }
        public double filmRating { get; set; }
        public int duration { get; set; }
        public string filmPoster { get; set; }
        public string trailer { get; set; }
        public class UpdateFilmCommandHandler : IRequestHandler<UpdateFilmCommand, Response<int>>
        {
            private readonly IFilmmRepositoryAsync _filmRepository;
            private readonly IMapper _mapper;
            public UpdateFilmCommandHandler(IFilmmRepositoryAsync filmRepository, IMapper mapper)
            {
                _filmRepository = filmRepository;
                _mapper = mapper;
            }
            public async Task<Response<int>> Handle(UpdateFilmCommand request, CancellationToken cancellationToken)
            {
                var _film = await _filmRepository.GetByIdAsync(request.Id);

                if (_film == null)
                {
                    throw new ApiException($"Film Not Found.");
                }
                else
                {
                    _film = _mapper.Map<Film>(request);
                    await _filmRepository.UpdateAsync(_film);
                    return new Response<int>(_film.Id);
                }
            }
        }
    }
}
