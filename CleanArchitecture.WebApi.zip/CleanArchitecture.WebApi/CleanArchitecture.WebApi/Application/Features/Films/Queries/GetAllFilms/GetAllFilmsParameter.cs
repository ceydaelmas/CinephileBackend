﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Films.Queries.GetAllFilms
{
    public class GetAllFilmsParameter : RequestParameter
    {
    }
}
