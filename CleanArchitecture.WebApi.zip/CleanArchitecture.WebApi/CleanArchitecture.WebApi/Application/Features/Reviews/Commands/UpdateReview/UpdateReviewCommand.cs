﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Reviews.Commands.UpdateReview
{
    public class UpdateReviewCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public string reviewContent { get; set; }
        public int? filmId { get; set; }
        public class UpdateReviewCommandHandler : IRequestHandler<UpdateReviewCommand, Response<int>>
        {
            private readonly IReviewRepositoryAsync _reviewRepository;
            private readonly IMapper _mapper;
            public UpdateReviewCommandHandler(IReviewRepositoryAsync reviewRepository, IMapper mapper)
            {
                _reviewRepository = reviewRepository;
                _mapper = mapper;
            }
            public async Task<Response<int>> Handle(UpdateReviewCommand request, CancellationToken cancellationToken)
            {
                var _review = await _reviewRepository.GetByIdAsync(request.Id);

                if (_review == null)
                {
                    throw new ApiException($"Review Not Found.");
                }
                else
                {
                    _review = _mapper.Map<Review>(request);
                    await _reviewRepository.UpdateAsync(_review);
                    return new Response<int>(_review.Id);
                }
            }
        }
    }
}
