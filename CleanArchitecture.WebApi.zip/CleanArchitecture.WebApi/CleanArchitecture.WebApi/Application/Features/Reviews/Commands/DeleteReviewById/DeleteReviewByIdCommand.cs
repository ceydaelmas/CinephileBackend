﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Reviews.Commands.DeleteReviewById
{
    public class DeleteReviewByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteReviewByIdCommandHandler : IRequestHandler<DeleteReviewByIdCommand, Response<int>>
        {
            private readonly IReviewRepositoryAsync _reviewRepository;
            public DeleteReviewByIdCommandHandler(IReviewRepositoryAsync reviewRepository)
            {
                _reviewRepository = reviewRepository;
            }
            public async Task<Response<int>> Handle(DeleteReviewByIdCommand command, CancellationToken cancellationToken)
            {
                var review = await _reviewRepository.GetByIdAsync(command.Id);
                if (review == null) throw new ApiException($"Review Not Found.");
                await _reviewRepository.DeleteAsync(review);
                return new Response<int>(review.Id);
            }
        }
    }
}
