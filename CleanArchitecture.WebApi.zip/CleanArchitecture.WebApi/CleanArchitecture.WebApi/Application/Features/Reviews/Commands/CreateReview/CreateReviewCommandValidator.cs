﻿using Application.Interfaces.Repositories;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Reviews.Commands.CreateReview
{
    public class CreateReviewCommandValidator : AbstractValidator<CreateReviewCommand>
    {
        private readonly IReviewRepositoryAsync reviewRepository;

        public CreateReviewCommandValidator(IReviewRepositoryAsync reviewRepository)
        {
            this.reviewRepository = reviewRepository;

            RuleFor(p => p.reviewContent)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull()
                .MaximumLength(50).WithMessage("{PropertyName} must not exceed 50 characters.");

            RuleFor(p => p.filmId)
                .NotEmpty().WithMessage("{PropertyName} is required.")
                .NotNull();

          

        }
    }
}
