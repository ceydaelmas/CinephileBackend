﻿using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Reviews.Commands.CreateReview
{
    public partial class CreateReviewCommand : IRequest<Response<int>>
    {
        public string reviewContent { get; set; }
        public int? filmId { get; set; }
    }
    public class CreateReviewCommandHandler : IRequestHandler<CreateReviewCommand, Response<int>>
    {
        private readonly IReviewRepositoryAsync _reviewRepository;
        private readonly IMapper _mapper;
        public CreateReviewCommandHandler(IReviewRepositoryAsync reviewRepository, IMapper mapper)
        {
            _reviewRepository = reviewRepository;
            _mapper = mapper;
        }

        public async Task<Response<int>> Handle(CreateReviewCommand request, CancellationToken cancellationToken)
        {
            var review = _mapper.Map<Review>(request);
            await _reviewRepository.AddAsync(review);
            return new Response<int>(review.Id);
        }
    }
}
