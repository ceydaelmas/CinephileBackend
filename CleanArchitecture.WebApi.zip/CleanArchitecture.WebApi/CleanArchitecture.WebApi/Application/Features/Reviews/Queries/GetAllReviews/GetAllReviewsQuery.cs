﻿using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Reviews.Queries.GetAllReviews
{
    public class GetAllReviewsQuery : IRequest<PagedResponse<IEnumerable<GetAllReviewsViewModel>>>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
    public class GetAllReviewsQueryHandler : IRequestHandler<GetAllReviewsQuery, PagedResponse<IEnumerable<GetAllReviewsViewModel>>>
    {
        private readonly IReviewRepositoryAsync _reviewRepository;
        private readonly IMapper _mapper;
        public GetAllReviewsQueryHandler(IReviewRepositoryAsync reviewRepository, IMapper mapper)
        {
            _reviewRepository = reviewRepository;
            _mapper = mapper;
        }

        public async Task<PagedResponse<IEnumerable<GetAllReviewsViewModel>>> Handle(GetAllReviewsQuery request, CancellationToken cancellationToken)
        {
            var validFilter = _mapper.Map<GetAllReviewsParameter>(request);

            var _review = await _reviewRepository.GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);

            //  GetPagedReponseAsync(validFilter.PageNumber, validFilter.PageSize);
            var reviewViewModel = _mapper.Map<IEnumerable<GetAllReviewsViewModel>>(_review);
            return new PagedResponse<IEnumerable<GetAllReviewsViewModel>>(reviewViewModel, validFilter.PageNumber, validFilter.PageSize);
        }
    }
}
