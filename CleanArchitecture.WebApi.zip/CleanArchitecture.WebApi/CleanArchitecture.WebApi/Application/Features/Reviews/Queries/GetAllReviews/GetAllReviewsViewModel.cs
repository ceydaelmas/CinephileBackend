﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Reviews.Queries.GetAllReviews
{
    public class GetAllReviewsViewModel
    {
        public string reviewContent { get; set; }
        public int? filmId { get; set; }
    }
}
