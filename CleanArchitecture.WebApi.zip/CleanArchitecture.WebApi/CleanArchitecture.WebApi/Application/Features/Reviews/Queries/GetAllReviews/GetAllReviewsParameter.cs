﻿using Application.Filters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Features.Reviews.Queries.GetAllReviews
{
    public class GetAllReviewsParameter : RequestParameter
    {
    }
}
