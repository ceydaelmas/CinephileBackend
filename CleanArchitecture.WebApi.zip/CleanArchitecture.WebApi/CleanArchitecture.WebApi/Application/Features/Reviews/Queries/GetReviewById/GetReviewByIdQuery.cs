﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Reviews.Queries.GetReviewById
{
   public class GetReviewByIdQuery : IRequest<Response<Review>>
    {
        public int Id { get; set; }
        public class GetReviewByIdQueryHandler : IRequestHandler<GetReviewByIdQuery, Response<Review>>
        {
            private readonly IReviewRepositoryAsync _reviewRepository;
            public GetReviewByIdQueryHandler(IReviewRepositoryAsync reviewRepository)
            {
                _reviewRepository = reviewRepository;
            }
            public async Task<Response<Review>> Handle(GetReviewByIdQuery query, CancellationToken cancellationToken)
            {
                var review = await _reviewRepository.GetByIdAsync(query.Id);
                if (review == null) throw new ApiException($"Review Not Found.");
                return new Response<Review>(review);
            }
        }
    }
}
