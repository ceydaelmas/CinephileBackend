﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Diaries.Commands.DeleteDiaryById
{
    public class DeleteDiaryByIdCommand : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public class DeleteDiaryByIdCommandHandler : IRequestHandler<DeleteDiaryByIdCommand, Response<int>>
        {
            private readonly IDiaryRepositoryAsync _diaryRepository;
            public DeleteDiaryByIdCommandHandler(IDiaryRepositoryAsync diaryRepository)
            {
                _diaryRepository = diaryRepository;
            }
            public async Task<Response<int>> Handle(DeleteDiaryByIdCommand command, CancellationToken cancellationToken)
            {
                var diary = await _diaryRepository.GetByIdAsync(command.Id);
                if (diary == null) throw new ApiException($"Diary Not Found.");
                await _diaryRepository.DeleteAsync(diary);
                return new Response<int>(diary.Id);
            }
        }
    }
}
