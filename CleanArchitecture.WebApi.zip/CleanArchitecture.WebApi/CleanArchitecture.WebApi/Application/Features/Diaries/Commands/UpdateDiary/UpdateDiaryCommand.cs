﻿using Application.Exceptions;
using Application.Interfaces.Repositories;
using Application.Wrappers;
using AutoMapper;
using Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Diaries.Commands.UpdateDiary
{
    public class UpdateDiaryCommand  : IRequest<Response<int>>
    {
        public int Id { get; set; }
        public int? filmId { get; set; }
        public DateTime addingDate { get; set; }

        public double userRating { get; set; }
        public class UpdateDiaryCommandHandler : IRequestHandler<UpdateDiaryCommand, Response<int>>
        {
            private readonly IDiaryRepositoryAsync _diaryRepository;
            private readonly IMapper _mapper;
            public UpdateDiaryCommandHandler(IDiaryRepositoryAsync diaryRepository, IMapper mapper)
            {
                _diaryRepository = diaryRepository;
                _mapper = mapper;
            }
            public async Task<Response<int>> Handle(UpdateDiaryCommand request, CancellationToken cancellationToken)
            {
                var _diary = await _diaryRepository.GetByIdAsync(request.Id);

                if (_diary == null)
                {
                    throw new ApiException($"Diary Not Found.");
                }
                else
                {
                    _diary = _mapper.Map<Diary>(request);
                    await _diaryRepository.UpdateAsync(_diary);
                    return new Response<int>(_diary.Id);
                }
            }
        }
    }
}
