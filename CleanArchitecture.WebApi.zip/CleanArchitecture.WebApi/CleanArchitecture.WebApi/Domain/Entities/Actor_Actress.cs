﻿using Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class Actor_Actress : AuditableBaseEntity
    {
        public string actorName { get; set; }
        public string actorSurname { get; set; }
        public string actorBrief { get; set; }
        public string actorImage { get; set; }//link

    }
}
