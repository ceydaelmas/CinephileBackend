﻿using Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class Director : AuditableBaseEntity
    {
        public string directorName { get; set; }
        public string directorSurname { get; set; }
        public string directorBrief { get; set; }
        public string directorImage { get; set; }//link

    }
}
