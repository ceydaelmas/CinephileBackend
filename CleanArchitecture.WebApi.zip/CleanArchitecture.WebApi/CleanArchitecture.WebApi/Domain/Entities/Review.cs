﻿using Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class Review : AuditableBaseEntity
    {
        public string reviewContent { get; set; }
        public int? filmId { get; set; }
    }
}
