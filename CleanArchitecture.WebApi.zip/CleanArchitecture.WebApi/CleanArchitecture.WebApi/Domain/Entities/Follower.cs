﻿using Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class Follower : AuditableBaseEntity
    {
        public int userId { get; set; }  //followed person
        public int followerId { get; set; } //follower
    }
}
